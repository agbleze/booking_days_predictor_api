# booking_days_predictor_api
Create a machine learning API for predicting number of days a client will book a room online for accommodation 
