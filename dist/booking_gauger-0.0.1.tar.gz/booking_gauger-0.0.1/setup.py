from setuptools import setup

setup(name='booking_gauger',
      version='0.0.1',
      description='This is a machnine learning package that runs as an API for predicting number of days a client will book a room online for accommodation',
      author='Agbleze Linus',
      license='MIT',
      packages=['booking_gauger'],
      zip_safe=False
      )